# Bitget交易机器人安装指南

## 快速安装

1. **准备工作**
   - 安装 [Node.js](https://nodejs.org/) (16.0或更高版本)
   - 获取Bitget API密钥 (API Key, Secret和Passphrase)

2. **安装步骤**
   ```bash
   # 解压下载的文件包
   
   # 进入项目目录
   cd bitget-trading-bot
   
   # 安装依赖
   npm install
   
   # 配置API密钥
   # 复制config.example.json为config.json并编辑
   ```

3. **配置文件**
   - 将`config.example.json`复制为`config.json`
   - 编辑`config.json`文件，填入你的Bitget API凭据：
   ```json
   {
     "apiKey": "你的Bitget API Key",
     "apiSecret": "你的Bitget API Secret",
     "apiPassphrase": "你的Bitget API Passphrase",
     "buyAmountUSDT": 10,
     "takeProfitPercent": 3,
     "stopLossPercent": 3
   }
   ```

4. **启动服务器**
   - Windows: 双击`restart.bat`或运行`node server.js`
   - Linux/Mac: 运行`node server.js`

5. **访问控制面板**
   - 打开浏览器，访问 http://localhost:3000

## 排错指南

### 常见问题

1. **无法启动服务器**
   - 检查Node.js是否正确安装: `node -v`
   - 检查是否安装了所有依赖: `npm install`
   - 检查端口3000是否被占用

2. **API连接失败**
   - 确认API密钥正确无误
   - 检查Bitget账户API权限设置
   - 确认网络连接正常

3. **下单失败**
   - 检查账户余额是否充足
   - 交易对是否存在或已下线
   - 检查订单参数是否有误

## 测试模式

如果您想先测试系统而不进行实际交易：
1. 在`config.json`中将API凭据留空
2. 系统将自动切换到测试模式
3. 您可以模拟交易流程而不会执行真实订单

## 升级说明

更新到新版本时：
1. 备份您的`config.json`和`active_trades.json`
2. 替换所有文件为新版本
3. 恢复您的备份文件
4. 重启服务器 