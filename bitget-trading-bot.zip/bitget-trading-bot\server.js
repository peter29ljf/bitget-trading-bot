const express = require('express');
const fs = require('fs').promises;
const path = require('path');
// Assuming the bitget-api library is installed in node_modules
// And its main export provides access to RestClientV2
// Adjust the import based on the actual library structure if needed
const { RestClientV2 } = require('bitget-api'); // Or potentially require('./lib') if run locally

const app = express();
const port = 3000;

// --- Configuration and State ---
const CONFIG_PATH = path.join(__dirname, 'config.json');
const TRADES_PATH = path.join(__dirname, 'active_trades.json');

let config = {};
let activeTrades = [];
let bitgetClient = null; // Initialize as null
let testMode = false; // 添加测试模式标志

// --- Middleware ---
app.use(express.json()); // Middleware to parse JSON bodies
app.use(express.urlencoded({ extended: true })); // Middleware for form data

// --- Helper Functions ---

// Function to initialize Bitget client
async function initializeBitgetClient() {
    if (config.apiKey && config.apiSecret && config.apiPassphrase) {
        try {
             bitgetClient = new RestClientV2({
                apiKey: config.apiKey,
                apiSecret: config.apiSecret,
                apiPass: config.apiPassphrase,
                // Optional: Add options like recvWindow or debug flags if needed
            });
             console.log("Bitget客户端初始化成功。");
             
             // 测试连接
             try {
                 // 尝试获取服务器时间以验证连接
                 const timeResponse = await bitgetClient.getServerTime();
                 if (timeResponse && timeResponse.code === '00000') {
                     console.log("Bitget API连接测试成功!");
                     return true;
                 } else {
                     console.error("Bitget API连接测试失败:", timeResponse);
                     bitgetClient = null;
                 }
             } catch (testError) {
                 console.error("Bitget API连接测试失败:", testError);
                 bitgetClient = null;
             }
        } catch (error) {
             console.error("Bitget客户端初始化失败:", error);
             bitgetClient = null;
        }
    } else {
        console.warn("Bitget客户端未初始化: 配置中缺少API密钥、密钥或密码。");
        console.log("启用测试模式，可以模拟交易流程但不会实际执行订单。");
        testMode = true;
        bitgetClient = null;
    }
    return false;
}

// Function to load config
async function loadConfig() {
    try {
        const data = await fs.readFile(CONFIG_PATH, 'utf8');
        const loadedConfig = JSON.parse(data);
        // Merge loaded config with defaults to ensure all keys exist
        config = {
            apiKey: "",
            apiSecret: "",
            apiPassphrase: "",
            buyAmountUSDT: 10,
            takeProfitPercent: 1.5,
            stopLossPercent: 1,
            lastSignal: null,
            ...loadedConfig // Overwrite defaults with loaded values
        };

        // Trim keys immediately after loading
        if (config.apiKey) config.apiKey = config.apiKey.trim();
        if (config.apiSecret) config.apiSecret = config.apiSecret.trim();
        if (config.apiPassphrase) config.apiPassphrase = config.apiPassphrase.trim();

        console.log("配置已加载，API凭据" + (config.apiKey ? "已设置" : "未设置") + ":", { 
            buyAmountUSDT: config.buyAmountUSDT, 
            takeProfitPercent: config.takeProfitPercent,
            stopLossPercent: config.stopLossPercent
        });
        await initializeBitgetClient();
    } catch (error) {
        if (error.code === 'ENOENT') {
             console.log("config.json未找到，创建默认配置。");
             config = {
                apiKey: "", apiSecret: "", apiPassphrase: "",
                buyAmountUSDT: 10, takeProfitPercent: 1.5, stopLossPercent: 1, lastSignal: null
             };
             await saveConfig();
        } else {
            console.error("加载config.json时出错:", error);
            // Use default values if file is corrupt or unreadable
            config = {
                 apiKey: "", apiSecret: "", apiPassphrase: "",
                 buyAmountUSDT: 10, takeProfitPercent: 1.5, stopLossPercent: 1, lastSignal: null
            };
            console.warn("由于加载错误，使用默认/空配置值。");
        }
        await initializeBitgetClient();
    }
}

// Function to load active trades
async function loadTrades() {
    try {
        const data = await fs.readFile(TRADES_PATH, 'utf8');
        activeTrades = JSON.parse(data);
        console.log("已加载活跃交易。");
    } catch (error) {
        if (error.code === 'ENOENT') {
            console.log("active_trades.json未找到，以空交易列表启动。");
            activeTrades = [];
            await saveTrades();
        } else {
            console.error("加载active_trades.json时出错:", error);
            activeTrades = [];
        }
    }
}

// Function to save active trades
async function saveTrades() {
    try {
        await fs.writeFile(TRADES_PATH, JSON.stringify(activeTrades, null, 2), 'utf8');
    } catch (error) {
        console.error("保存active_trades.json时出错:", error);
    }
}

// Function to save config changes
async function saveConfig() {
    try {
        const configToSave = { ...config };
        await fs.writeFile(CONFIG_PATH, JSON.stringify(configToSave, null, 2), 'utf8');
        console.log("配置已保存。");
    } catch (error) {
        console.error("保存config.json时出错:", error);
    }
}

// 移除动态精度计算函数，改为固定精度
function getFixedPrecision() {
    return {
        pricePrecision: 6,  // 价格精度固定为6位
        quantityPrecision: 6  // 数量精度固定为6位
    };
}

// --- Static Files for UI ---
app.use(express.static('public'));

// --- API Routes ---

// Endpoint to receive trading signals
app.post('/signal', async (req, res) => {
    const signal = req.body;
    console.log(`收到信号:`, signal);

    if (!signal || !signal.COINNAME || !signal.SIDE) {
        return res.status(400).json({ error: '无效的信号格式。必需字段: COINNAME, SIDE' });
    }

    const symbol = signal.COINNAME;
    const side = signal.SIDE.toLowerCase(); // 确保小写

    if (!bitgetClient && !testMode) {
         console.error("Bitget客户端未初始化，且测试模式未启用。");
         return res.status(500).json({ error: 'Bitget客户端未初始化，且测试模式未启用。请配置有效的API凭据或启用测试模式。' });
    }

    // 在测试模式下模拟交易
    if (testMode) {
        console.log(`[测试模式] 处理${side}信号: ${symbol}`);
        
        if (side === 'buy') {
            try {
                // 模拟市场价格
                const mockPrice = symbol.includes('BTC') ? 65000 : 
                                 symbol.includes('ETH') ? 3500 : 
                                 symbol.includes('XRP') ? 0.60 :
                                 symbol.includes('DOGE') ? 0.10 :
                                 symbol.includes('SHIB') ? 0.00001 : 1.0;
                
                console.log(`[测试模式] ${symbol} 模拟价格: ${mockPrice}`);
                
                // 计算买入数量 - 使用固定精度
                const buyQuantity = (config.buyAmountUSDT / mockPrice);
                const precision = getFixedPrecision();
                const quantityToOrder = buyQuantity.toFixed(precision.quantityPrecision);
                
                // 计算止盈止损价格 - 模拟实盘的精度调整逻辑
                // 从6位精度开始，如果有问题可以降低到5位，最低到3位
                let tpslPrecision = 6; // 默认从6位精度开始
                let takeProfitPrice = '';
                let stopLossPrice = '';
                
                // 在测试模式下，我们只是简单模拟精度调整的过程
                // 对于某些特定币种，使用较低精度模拟可能出现的精度问题
                if (symbol.includes('SHIB') || symbol.includes('DOGE')) {
                    // 对于小额币种，使用较低精度模拟精度调整过程
                    console.log(`[测试模式] 检测到小额币种 ${symbol}，模拟精度调整过程`);
                    tpslPrecision = 4;
                }
                
                takeProfitPrice = (mockPrice * (1 + config.takeProfitPercent / 100)).toFixed(tpslPrecision);
                stopLossPrice = (mockPrice * (1 - config.stopLossPercent / 100)).toFixed(tpslPrecision);
                
                console.log(`[测试模式] 使用${tpslPrecision}位精度: 止盈价=${takeProfitPrice}, 止损价=${stopLossPrice}`);
                
                console.log(`[测试模式] 模拟买入 ${quantityToOrder} ${symbol} @ ${mockPrice}`);
                
                // 生成模拟订单ID
                const mockOrderId = `test_${Date.now()}`;
                
                // 记录模拟交易
                const newTrade = {
                    symbol: symbol,
                    orderId: mockOrderId,
                    clientOid: `test_${symbol}_${Date.now()}`,
                    entryPrice: mockPrice,
                    buyAmountUSDT: config.buyAmountUSDT,
                    quantity: quantityToOrder,
                    filledQuantity: quantityToOrder, // 在测试模式下假设完全成交
                    takeProfitPercent: config.takeProfitPercent,
                    stopLossPercent: config.stopLossPercent,
                    takeProfitPrice: takeProfitPrice,
                    stopLossPrice: stopLossPrice,
                    status: 'active',
                    timestamp: new Date().toISOString(),
                    isTestMode: true // 标记为测试模式交易
                };
                
                activeTrades.push(newTrade);
                await saveTrades();
                config.lastSignal = signal;
                await saveConfig();
                
                return res.status(200).json({ 
                    message: `[测试模式] ${symbol} 买入模拟成功`, 
                    trade: newTrade 
                });
                
            } catch (error) {
                console.error(`[测试模式] 处理买入信号时出错:`, error);
                return res.status(500).json({ 
                    error: `[测试模式] 处理买入信号失败`, 
                    details: error.message || error 
                });
            }
        } else if (side === 'sell') {
            try {
                // 在活跃交易中查找该币种的持仓
                const tradeIndex = activeTrades.findIndex(trade => trade.symbol === symbol && trade.status === 'active');
                if (tradeIndex === -1) {
                    console.log(`[测试模式] 未找到 ${symbol} 的活跃交易。忽略卖出信号。`);
                    return res.status(404).json({ 
                        message: `[测试模式] 未找到 ${symbol} 的活跃交易。` 
                    });
                }
                
                const tradeToSell = activeTrades[tradeIndex];
                const mockExitPrice = tradeToSell.entryPrice * (1 + (Math.random() * 2 - 1) * 0.05); // 在入场价格基础上上下5%随机浮动
                
                console.log(`[测试模式] 模拟卖出 ${tradeToSell.filledQuantity} ${symbol} @ ${mockExitPrice}`);
                
                // 计算盈亏
                const buyValue = tradeToSell.buyAmountUSDT;
                const sellValue = tradeToSell.filledQuantity * mockExitPrice;
                const profitLoss = sellValue - buyValue;
                const profitLossPercent = (profitLoss / buyValue) * 100;
                
                console.log(`[测试模式] 买入价值: ${buyValue.toFixed(2)} USDT`);
                console.log(`[测试模式] 卖出价值: ${sellValue.toFixed(2)} USDT`);
                console.log(`[测试模式] 盈亏: ${profitLoss.toFixed(2)} USDT (${profitLossPercent.toFixed(2)}%)`);
                
                // 从活跃交易中移除该交易
                activeTrades.splice(tradeIndex, 1);
                await saveTrades();
                config.lastSignal = signal;
                await saveConfig();
                
                return res.status(200).json({ 
                    message: `[测试模式] ${symbol} 卖出模拟成功`, 
                    profit: {
                        amount: profitLoss.toFixed(2),
                        percent: profitLossPercent.toFixed(2)
                    }
                });
                
            } catch (error) {
                console.error(`[测试模式] 处理卖出信号时出错:`, error);
                return res.status(500).json({ 
                    error: `[测试模式] 处理卖出信号失败`, 
                    details: error.message || error 
                });
            }
        }
    }

    // 如果不是测试模式，使用实际的Bitget API
    if (side === 'buy') {
        // --- Buy Logic ---
        console.log(`处理买入信号: ${symbol}...`);

        try {
            // 2. 获取市场价格
            console.log(`获取 ${symbol} 的市场价格...`);
            
            // 记录所有可用的API方法
            console.log("可用API方法:", Object.keys(bitgetClient).filter(key => typeof bitgetClient[key] === 'function'));
            
            // 尝试使用不同格式的交易对名称
            const symbolFormats = [
                symbol, // 原始格式 (如"BTCUSDT")
                symbol.replace(/USDT$/, "/USDT"), // 尝试"BTC/USDT"格式
                symbol.toUpperCase(), // 确保全大写
                symbol.replace(/USDT$/, "_USDT"), // 尝试"BTC_USDT"格式
                symbol.replace(/USDT$/, "-USDT") // 尝试"BTC-USDT"格式
            ];
            
            console.log("尝试以下交易对格式:", symbolFormats);
            
            // 使用原始格式先尝试
            const formattedSymbol = symbol;
            const tickerResponse = await bitgetClient.getSpotTicker({ symbol: formattedSymbol });
            console.log("交易对行情响应:", JSON.stringify(tickerResponse));
            
            if (!tickerResponse || tickerResponse.code !== '00000' || !tickerResponse.data || tickerResponse.data.length === 0) {
                throw new Error(`获取 ${symbol} 价格失败。响应: ${JSON.stringify(tickerResponse)}`);
            }
            const currentPrice = parseFloat(tickerResponse.data[0].lastPr);
            if (isNaN(currentPrice) || currentPrice <= 0) {
                 throw new Error(`收到无效的当前价格: ${tickerResponse.data[0].lastPr}`);
            }
            console.log(`${symbol} 当前价格: ${currentPrice}`);

            // 3. 计算买入数量
            const buyQuantity = (config.buyAmountUSDT / currentPrice);
            
            // 根据价格确定合适的精度
            const precision = getFixedPrecision();
            console.log(`根据当前价格 ${currentPrice} 确定精度: 价格精度=${precision.pricePrecision}, 数量精度=${precision.quantityPrecision}`);
            
            // 使用合适的精度
            const quantityToOrder = buyQuantity.toFixed(precision.quantityPrecision);
            console.log(`计算 ${config.buyAmountUSDT} USDT 可买入数量: ${quantityToOrder} ${symbol.replace('USDT','')}`);

            // 4. 检查要买入币种的余额
            // 提取基础币种名称（去掉USDT）
            const baseCoin = symbol.replace(/USDT$/, '');
            console.log(`检查 ${baseCoin} 余额...`);
            
            const baseBalanceResponse = await bitgetClient.getSpotAccountAssets({ coin: baseCoin });
            if (!baseBalanceResponse || baseBalanceResponse.code !== '00000') {
                console.log(`获取 ${baseCoin} 余额失败或币种不存在，假设为0继续交易。`);
            } else {
                // 如果成功获取到余额信息
                if (baseBalanceResponse.data && baseBalanceResponse.data.length > 0) {
                    const baseBalance = baseBalanceResponse.data[0];
                    const availableBaseBalance = parseFloat(baseBalance.available || "0");
                    const frozenBaseBalance = parseFloat(baseBalance.frozen || "0");
                    const totalBaseBalance = availableBaseBalance + frozenBaseBalance;
                    
                    console.log(`${baseCoin} 可用余额: ${availableBaseBalance}, 冻结余额: ${frozenBaseBalance}, 总余额: ${totalBaseBalance}`);
                    
                    // 5. 比较币种余额与所需买入数量
                    // 新逻辑: 如果总余额大于等于要买入的数量，停止交易
                    if (totalBaseBalance >= parseFloat(quantityToOrder)) {
                        console.log(`已持有足够的 ${baseCoin}（${totalBaseBalance}），超过要买入的数量（${quantityToOrder}）。停止交易。`);
                        return res.status(400).json({ message: `已持有足够的 ${baseCoin}（${totalBaseBalance}），超过要买入的数量（${quantityToOrder}）。停止交易。` });
                    }
                    console.log(`${baseCoin} 余额不足，可以继续交易`);
                } else {
                    console.log(`未找到 ${baseCoin} 余额信息，假设为0继续交易。`);
                }
            }

            // 6. 计算TP/SL价格
            const takeProfitPrice = (currentPrice * (1 + config.takeProfitPercent / 100)).toFixed(precision.pricePrecision);
            const stopLossPrice = (currentPrice * (1 - config.stopLossPercent / 100)).toFixed(precision.pricePrecision);
            console.log(`计算止盈价: ${takeProfitPrice}, 止损价: ${stopLossPrice}`);

            // 7. 下市价单
            const clientOrderId = `buy_${symbol}_${Date.now()}`;
            console.log(`下 ${config.buyAmountUSDT} USDT 的市价买单...`);
            
            // 创建一个递归函数来尝试不同的精度
            async function tryPlaceOrderWithPrecision(currentPrecision) {
                console.log(`尝试使用${currentPrecision}位价格精度下单...`);
                
                // 使用当前精度格式化止盈止损价格
                const tpPrice = (currentPrice * (1 + config.takeProfitPercent / 100)).toFixed(currentPrecision);
                const slPrice = (currentPrice * (1 - config.stopLossPercent / 100)).toFixed(currentPrecision);
                
                console.log(`当前精度${currentPrecision}: 止盈价=${tpPrice}, 止损价=${slPrice}`);
                
                // 统一处理所有币种，都使用USDT金额下单，并设置止盈止损
                const orderParams = {
                    symbol: formattedSymbol,
                    side: 'buy',
                    orderType: 'market',
                    force: 'gtc',
                    size: config.buyAmountUSDT.toString(), // 买入时使用USDT金额下单
                    clientOid: `${clientOrderId}_p${currentPrecision}`,
                    presetTakeProfitPrice: tpPrice,
                    presetStopLossPrice: slPrice
                };
                
                try {
                    console.log(`尝试下单 (精度=${currentPrecision}): `, orderParams);
                    const orderResponse = await bitgetClient.spotSubmitOrder(orderParams);
                    
                    if (orderResponse && orderResponse.code === '00000' && orderResponse.data && orderResponse.data.orderId) {
                        console.log(`下单成功 (精度=${currentPrecision})! 订单ID: ${orderResponse.data.orderId}`);
                        return {
                            success: true,
                            response: orderResponse,
                            orderId: orderResponse.data.orderId,
                            clientOrderId: orderParams.clientOid,
                            takeProfitPrice: tpPrice,
                            stopLossPrice: slPrice
                        };
                    } else {
                        console.log(`下单响应异常 (精度=${currentPrecision}):`, orderResponse);
                        return { success: false, error: `下单响应异常: ${JSON.stringify(orderResponse)}` };
                    }
                } catch (orderError) {
                    // 检查错误是否与价格精度相关
                    const errorMsg = orderError.body?.msg || orderError.message || JSON.stringify(orderError);
                    console.error(`下单失败 (精度=${currentPrecision}):`, errorMsg);
                    
                    const isPrecisionError = errorMsg.includes('price scale') || 
                                           errorMsg.includes('precision') || 
                                           errorMsg.includes('decimal');
                    
                    if (isPrecisionError && currentPrecision > 3) {
                        console.log(`错误似乎与价格精度有关，尝试降低精度到${currentPrecision - 1}位`);
                        return { success: false, isPrecisionError: true };
                    } else {
                        return { success: false, error: errorMsg, isPrecisionError: false };
                    }
                }
            }
            
            // 尝试不同的精度，从6开始降低到3
            let currentPrecision = 6;
            let orderResult = null;
            
            while (currentPrecision >= 3) {
                orderResult = await tryPlaceOrderWithPrecision(currentPrecision);
                
                if (orderResult.success) {
                    break; // 下单成功，退出循环
                } else if (!orderResult.isPrecisionError) {
                    throw new Error(`下单失败: ${orderResult.error}`); // 非精度错误，直接抛出
                }
                
                // 降低精度重试
                currentPrecision--;
            }
            
            if (!orderResult || !orderResult.success) {
                throw new Error("所有精度尝试均失败，无法下单");
            }
            
            const orderId = orderResult.orderId;
            console.log(`市价买单下单成功。订单ID: ${orderId}, 客户端ID: ${orderResult.clientOrderId}`);

            // 8. 等待并确认订单
            console.log("等待3秒后确认订单详情...");
            await new Promise(resolve => setTimeout(resolve, 3000));

            console.log(`获取订单ID: ${orderId} 的详情...`);
            const orderDetailsResponse = await bitgetClient.getSpotOrder({ orderId: orderId, symbol: formattedSymbol });
            console.log("订单详情响应:", orderDetailsResponse);

             if (!orderDetailsResponse || orderDetailsResponse.code !== '00000' || !orderDetailsResponse.data || orderDetailsResponse.data.length === 0) {
                console.warn(`下单后无法立即获取订单 ${orderId} 的详情。将记录基本信息。`);
                // 继续记录基本信息
                 const newTrade = {
                     symbol: symbol,
                     orderId: orderId,
                     clientOid: orderResult.clientOrderId,
                     entryPrice: null, // 标记为null
                     buyAmountUSDT: config.buyAmountUSDT,
                     quantity: quantityToOrder,
                     filledQuantity: null,
                     takeProfitPercent: config.takeProfitPercent,
                     stopLossPercent: config.stopLossPercent,
                     takeProfitPrice: orderResult.takeProfitPrice,
                     stopLossPrice: orderResult.stopLossPrice,
                     status: 'pending_confirmation',
                     timestamp: new Date().toISOString()
                 };
                 activeTrades.push(newTrade);
                 await saveTrades();
                 config.lastSignal = signal;
                 await saveConfig();
                 return res.status(202).json({ message: `${symbol} 买单已下单(等待确认)`, orderId: orderId, trade: newTrade });
             }

            // 9. 获取实际成交价格和数量，并记录交易详情
            const orderDetails = orderDetailsResponse.data[0];
            let actualFilledQuantity = 0;
            let actualAvgPrice = 0;
            
            // 提取baseVolume作为实际数量
            if (orderDetails.baseVolume) {
                actualFilledQuantity = parseFloat(orderDetails.baseVolume);
            } else if (orderDetails.fillSize) {
                actualFilledQuantity = parseFloat(orderDetails.fillSize);
            }
            
            // 提取priceAvg作为实际成交价格
            if (orderDetails.priceAvg) {
                actualAvgPrice = parseFloat(orderDetails.priceAvg);
            } else if (orderDetails.avgFillPrice) {
                actualAvgPrice = parseFloat(orderDetails.avgFillPrice);
            }
            
            const orderStatus = orderDetails.status;

            console.log(`订单 ${orderId} 状态: ${orderStatus}, 成交数量: ${actualFilledQuantity}, 平均价格: ${actualAvgPrice}`);

            // 记录交易信息
            const newTrade = {
                symbol: symbol,
                orderId: orderId,
                clientOid: orderDetails.clientOid,
                entryPrice: actualAvgPrice > 0 ? actualAvgPrice : currentPrice, // 使用平均成交价格，如果为0则使用市场价格
                buyAmountUSDT: config.buyAmountUSDT,
                quantity: quantityToOrder, // 原始请求数量
                filledQuantity: actualFilledQuantity,
                takeProfitPercent: config.takeProfitPercent,
                stopLossPercent: config.stopLossPercent,
                takeProfitPrice: orderResult.takeProfitPrice,
                stopLossPrice: orderResult.stopLossPrice,
                status: 'active', // 标记为活跃
                timestamp: new Date(parseInt(orderDetails.cTime)).toISOString() // 使用订单创建时间
            };

            activeTrades.push(newTrade);
            await saveTrades();
            config.lastSignal = signal; // 记录触发交易的信号
            await saveConfig();

            console.log(`成功处理并记录 ${symbol} 的买入交易`);
            res.status(200).json({ message: `${symbol} 买单处理成功`, trade: newTrade });

        } catch (error) {
            console.error(`处理 ${symbol} 买入信号时出错:`, error);
            // 检查是否为Bitget API错误
            const errorMessage = error?.response?.data?.msg || error.message || error;
            res.status(500).json({ error: `处理 ${symbol} 买入信号失败`, details: errorMessage });
        }

    } else if (side === 'sell') {
        // --- Sell Logic ---
        console.log(`处理卖出信号: ${symbol}...`);

        try {
            // 1. 查询是否有该币种的订单记录（未完成订单）
            console.log(`查询 ${symbol} 的未完成订单...`);
            const openOrdersParams = {
                symbol: symbol,
                tpslType: 'tpsl' // 查询止盈止损订单
            };
            
            const openOrdersResponse = await bitgetClient.getSpotOpenOrders(openOrdersParams);
            console.log("未完成订单响应:", JSON.stringify(openOrdersResponse));
            
            let openOrders = [];
            if (openOrdersResponse && openOrdersResponse.code === '00000' && openOrdersResponse.data) {
                openOrders = openOrdersResponse.data;
                console.log(`找到 ${openOrders.length} 个未完成的 ${symbol} 订单`);
                
                // 输出所有可用的API方法
                console.log("所有可用的API方法:", Object.keys(bitgetClient).filter(key => typeof bitgetClient[key] === 'function'));
                // 查找包含cancel的方法
                console.log("包含cancel的方法:", Object.keys(bitgetClient).filter(key => typeof bitgetClient[key] === 'function' && key.toLowerCase().includes('cancel')));
                
                // 2. 取消相关订单
                for (const order of openOrders) {
                    console.log(`取消订单 ${order.orderId}...`);
                    try {
                        // 添加tpslType参数和symbol参数
                        const cancelParams = {
                            symbol: symbol,
                            orderId: order.orderId,
                            tpslType: 'tpsl'  // 添加tpslType参数为tpsl
                        };
                        const cancelResponse = await bitgetClient.postPrivate('/api/v2/spot/trade/cancel-order', cancelParams);
                        console.log(`订单 ${order.orderId} 取消响应:`, JSON.stringify(cancelResponse));
                    } catch (cancelError) {
                        console.error(`取消订单 ${order.orderId} 失败:`, cancelError);
                        // 即使取消失败也继续处理
                    }
                }
            } else {
                console.log(`未找到 ${symbol} 的未完成订单`);
            }
            
            // 3. 在活跃交易中查找该币种的持仓
        const tradeIndex = activeTrades.findIndex(trade => trade.symbol === symbol && trade.status === 'active');
        if (tradeIndex === -1) {
                console.log(`未找到 ${symbol} 的活跃交易。忽略卖出信号。`);
                return res.status(404).json({ message: `未找到 ${symbol} 的活跃交易。` });
        }
        const tradeToSell = activeTrades[tradeIndex];

            // 4. 获取要卖出的数量
            const quantityToSell = tradeToSell.filledQuantity;
            
            // 使用原始符号格式
            const formattedSymbol = symbol;

            if (!quantityToSell || quantityToSell <= 0) {
                // 尝试移除可能不一致的交易记录
                activeTrades.splice(tradeIndex, 1);
                await saveTrades();
                console.warn(`${symbol} 的交易记录中成交数量无效或为零 (${quantityToSell})。已移除记录。`);
                return res.status(400).json({ message: `无法卖出 ${symbol}: 交易记录中数量无效 (${quantityToSell})。已移除记录。` });
            }

            console.log(`尝试卖出 ${quantityToSell} ${symbol}...`);

            // 5. 下市价卖单
            const clientOrderId = `sell_${symbol}_${Date.now()}`;
            const orderParams = {
                symbol: formattedSymbol,
                side: 'sell',
                orderType: 'market',
                force: 'gtc',
                size: quantityToSell.toString(), // 卖出时使用数量
                clientOid: clientOrderId
            };
            console.log("卖单参数:", orderParams);

            const sellOrderResponse = await bitgetClient.spotSubmitOrder(orderParams);
            console.log("卖单提交响应:", sellOrderResponse);

            if (!sellOrderResponse || sellOrderResponse.code !== '00000' || !sellOrderResponse.data || !sellOrderResponse.data.orderId) {
                // 如果卖出订单失败，暂时不移除交易记录
                throw new Error(`下卖单失败，币种: ${symbol}。响应: ${JSON.stringify(sellOrderResponse)}`);
            }

            const sellOrderId = sellOrderResponse.data.orderId;
            console.log(`${symbol} 市价卖单下单成功。订单ID: ${sellOrderId}`);

            // 6. 从活跃交易中移除该交易
            activeTrades.splice(tradeIndex, 1);
            await saveTrades();

            // 7. 更新最后接收的信号
            config.lastSignal = signal;
            await saveConfig();

            console.log(`成功处理并移除 ${symbol} 的卖出交易`);
            res.status(200).json({ message: `${symbol} 卖单成功下单`, orderId: sellOrderId });

        } catch (error) {
            console.error(`处理 ${symbol} 卖出信号时出错:`, error);
            const errorMessage = error?.response?.data?.msg || error.message || error;
            res.status(500).json({ error: `处理 ${symbol} 卖出信号失败`, details: errorMessage });
        }

    } else {
        res.status(400).json({ error: '无效的SIDE值。必须为 "BUY" 或 "SELL"。' });
    }
});

// Endpoint to get current configuration (excluding sensitive keys)
app.get('/config', (req, res) => {
    // Return non-sensitive parts of the config
    const { apiKey, apiSecret, apiPassphrase, ...safeConfig } = config;
    res.json(safeConfig);
});

// 添加新的端点返回API连接状态
app.get('/api-status', (req, res) => {
    const apiConnected = bitgetClient !== null;
    const statusData = {
        connected: apiConnected,
        testMode: testMode,
        message: apiConnected ? "API连接正常" : (testMode ? "测试模式已启用" : "API未连接")
    };
    res.json(statusData);
});

// 添加新的端点返回活跃交易信息
app.get('/active-trades', (req, res) => {
    const tradesWithMetadata = {
        trades: activeTrades,
        count: activeTrades.length,
        testMode: testMode,
        lastUpdate: new Date().toISOString()
    };
    res.json(tradesWithMetadata);
});

// Endpoint to update configuration from UI
app.post('/config', async (req, res) => {
    const {
        buyAmountUSDT,
        takeProfitPercent,
        stopLossPercent
    } = req.body;

    // 记录收到的交易参数
    console.log("收到交易参数更新请求，数据为:");
    console.log(`  买入金额USDT: ${buyAmountUSDT}`);
    console.log(`  止盈百分比: ${takeProfitPercent}`);
    console.log(`  止损百分比: ${stopLossPercent}`);

    // 基本验证
    if (buyAmountUSDT === undefined || takeProfitPercent === undefined || stopLossPercent === undefined) {
       return res.status(400).send('缺少必需的交易参数（买入金额、止盈%、止损%）。');
    }
    
    // 转换和验证数值
    const buyAmount = parseFloat(buyAmountUSDT);
    const tpPercent = parseFloat(takeProfitPercent);
    const slPercent = parseFloat(stopLossPercent);

    if (isNaN(buyAmount) || buyAmount <= 0) {
        return res.status(400).send('买入金额USDT无效。必须为正数。');
    }
    if (isNaN(tpPercent) || tpPercent <= 0) {
        return res.status(400).send('止盈百分比无效。必须为正数。');
    }
    if (isNaN(slPercent) || slPercent <= 0) {
       return res.status(400).send('止损百分比无效。必须为正数。');
    }

    // 更新配置对象 - 只更新交易参数
    let configUpdated = false;

    if (config.buyAmountUSDT !== buyAmount) {
        config.buyAmountUSDT = buyAmount;
        configUpdated = true;
    }
    if (config.takeProfitPercent !== tpPercent) {
        config.takeProfitPercent = tpPercent;
        configUpdated = true;
    }
    if (config.stopLossPercent !== slPercent) {
        config.stopLossPercent = slPercent;
        configUpdated = true;
    }

    if (configUpdated) {
        await saveConfig();
        console.log("交易参数已更新:", { 
        buyAmountUSDT: config.buyAmountUSDT,
        takeProfitPercent: config.takeProfitPercent,
        stopLossPercent: config.stopLossPercent
    });
        res.status(200).send({ 
            message: '交易参数已更新成功', 
            config: { 
                buyAmountUSDT: config.buyAmountUSDT, 
                takeProfitPercent: config.takeProfitPercent, 
                stopLossPercent: config.stopLossPercent 
            } 
        });
    } else {
        console.log("无需更新，参数未变化");
        res.status(200).send({ message: '参数未变化，无需更新', config: safeConfig });
    }
});

// --- Helper to generate HTML UI ---
app.get('/', (req, res) => {
    // 准备一个简单的HTML界面，显示当前配置和表单
    const { apiKey, apiSecret, apiPassphrase, ...safeConfig } = config;
    
    const activeTradesHtml = activeTrades.map(trade => `
        <div class="trade ${trade.isTestMode ? 'test-mode' : ''}">
            <h3>${trade.symbol} ${trade.isTestMode ? '(测试)' : ''}</h3>
            <p>入场价: ${trade.entryPrice || 'Pending'}</p>
            <p>止盈价: ${trade.takeProfitPrice} (${trade.takeProfitPercent}%)</p>
            <p>止损价: ${trade.stopLossPrice} (${trade.stopLossPercent}%)</p>
            <p>数量: ${trade.filledQuantity || trade.quantity} ${trade.symbol.replace('USDT','')}</p>
            <p>状态: ${trade.status}</p>
            <p>交易时间: ${new Date(trade.timestamp).toLocaleString()}</p>
            <button class="sell-btn" onclick="sendSignal('${trade.symbol}', 'SELL')">卖出</button>
        </div>
    `).join('') || '<p>当前没有活跃交易</p>';

    const html = `
    <!DOCTYPE html>
    <html>
    <head>
        <title>交易机器人控制面板</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/style.css">
    </head>
    <body>
        <div id="loading-overlay" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 999; justify-content: center; align-items: center; color: white; font-weight: bold;">
            处理中...
        </div>

        <h1>交易机器人控制面板</h1>
        
        <div class="section">
            <h2>系统状态</h2>
            <p>运行模式: <span class="mode-indicator ${testMode ? 'mode-test' : 'mode-live'}">${testMode ? '测试模式' : '实盘模式'}</span></p>
            <p>测试模式会模拟交易流程，但不会实际执行订单。实盘模式需要配置有效的API凭据。</p>
            <p class="note">注意: API凭据需要在服务器端的config.json文件中配置。</p>
        </div>
        
        <div class="section">
            <h2>交易参数</h2>
            <form id="config-form" action="/config" method="post">
                <div>
                    <label for="buyAmountUSDT">每次买入金额 (USDT):</label>
                    <input type="number" id="buyAmountUSDT" name="buyAmountUSDT" value="${safeConfig.buyAmountUSDT}" min="1" step="1" required>
                </div>
                <div>
                    <label for="takeProfitPercent">止盈百分比 (%):</label>
                    <input type="number" id="takeProfitPercent" name="takeProfitPercent" value="${safeConfig.takeProfitPercent}" min="0.1" step="0.1" required>
                </div>
                <div>
                    <label for="stopLossPercent">止损百分比 (%):</label>
                    <input type="number" id="stopLossPercent" name="stopLossPercent" value="${safeConfig.stopLossPercent}" min="0.1" step="0.1" required>
                </div>
                <button type="submit">更新交易参数</button>
        </form>
        </div>
        
        <div class="section">
            <h2>发送交易信号</h2>
            <div class="signal-form">
                <div>
                    <label for="signalCoin">交易对:</label>
                    <select id="signalCoin">
                        <option value="BTCUSDT">BTCUSDT (比特币)</option>
                        <option value="ETHUSDT">ETHUSDT (以太坊)</option>
                        <option value="BNBUSDT">BNBUSDT (币安币)</option>
                        <option value="XRPUSDT">XRPUSDT (瑞波币)</option>
                        <option value="ADAUSDT">ADAUSDT (艾达币)</option>
                        <option value="DOGEUSDT">DOGEUSDT (狗狗币)</option>
                        <option value="SHIBUSDT">SHIBUSDT (柴犬币)</option>
                        <option value="SOLUSDT">SOLUSDT (索拉纳)</option>
                        <option value="DOTUSDT">DOTUSDT (波卡)</option>
                        <option value="MATICUSDT">MATICUSDT (Polygon)</option>
                    </select>
                </div>
                <div>
                    <label for="signalSide">操作:</label>
                    <select id="signalSide">
                        <option value="BUY">买入</option>
                        <option value="SELL">卖出</option>
                    </select>
                </div>
                <button type="button" id="send-signal-btn">发送信号</button>
            </div>
        </div>
        
        <div class="section">
            <h2>活跃交易</h2>
            <div id="active-trades">
                ${activeTradesHtml}
            </div>
        </div>
        
        <div class="footer">
            <p>最后更新时间: ${new Date().toLocaleString()}</p>
        </div>
    </body>
    </html>
    `;
    
    res.send(html);
});

// --- Initialize and Start Server ---
async function startServer() {
    // Load configuration and trades on startup
    await loadConfig();
    await loadTrades();
    
    // 检查是否在测试模式
    if (!bitgetClient) {
        console.log("⚠️ Bitget API未连接");
        if (testMode) {
            console.log("✅ 测试模式已启用，可以模拟交易流程但不会实际执行订单");
        } else {
            console.log("❌ API凭据无效或未设置，将无法处理交易信号");
            console.log("   请在config.json文件中配置正确的API凭据");
        }
    } else {
        console.log("✅ Bitget API已连接，实盘模式");
    }
    
    // Start listening
    app.listen(port, () => {
        console.log(`✅ 交易机器人服务器在 http://localhost:${port} 上运行中`);
    });
}

startServer(); 